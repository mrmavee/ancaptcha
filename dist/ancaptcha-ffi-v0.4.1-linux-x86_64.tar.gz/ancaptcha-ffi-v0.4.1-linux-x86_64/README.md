<div align="center">

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)
[![Rust Version](https://img.shields.io/badge/rust-1.92%2B-blue)](https://www.rust-lang.org/)
[![Crates.io](https://img.shields.io/crates/v/ancaptcha.svg)](https://crates.io/crates/ancaptcha)
[![Downloads](https://img.shields.io/crates/d/ancaptcha.svg)](https://crates.io/crates/ancaptcha)
[![Coverage](assets/badges/coverage.png)](https://git.mrmave.work/maverick/ancaptcha)

<br />
<img src="assets/logo.png" alt="anCaptcha Logo" width="128" />

# anCaptcha

**No-JS, stateless captcha engine implemented in Rust for cross-language integration.**

[Security](docs/SECURITY.md)


</div>

<details>
  <summary>Table of Contents</summary>
  <ol>
    <li><a href="#overview">Overview</a></li>
    <li><a href="#key-features">Key Features</a></li>
    <li><a href="#preview">Preview</a></li>
    <li><a href="#architecture">Architecture</a></li>
    <li><a href="#configuration">Configuration</a></li>
    <li><a href="#installation-rust">Installation (Rust)</a></li>
    <li><a href="#quick-start-build-from-source">Quick Start</a></li>
    <li><a href="#custom-assets">Custom Assets</a></li>
    <li><a href="#pre-built-library-go-python-php">Pre-built Library</a></li>
    <li><a href="#manual-verification-recommended">Manual Verification</a></li>
    <li><a href="#security-and-compliance">Security and Compliance</a></li>
    <li><a href="#repositories">Repositories</a></li>
    <li><a href="#license">License</a></li>
    <li><a href="#donation">Donation</a></li>
  </ol>
</details>

## Overview

AnCaptcha is a stateless captcha engine implemented in Rust for cross-language integration. Originally designed for Tor Browser's "Safest" mode where JavaScript is strictly disabled.

## Key Features

- **No-JavaScript**: Challenges are entirely driven by CSS and HTML; no client-side scripts are required for rendering or interaction.
- **Stateless Verification**: Uses authenticated encryption (ChaCha20-Poly1305) to store challenge state in tokens, eliminating the need for server-side sessions.
- **High-Level Wrappers**: Ready-to-use implementations for Go, Python, and PHP are provided in the `examples/` directory. **Note: These are the only three officially supported language wrappers provided.**

## Preview

| Style | Image |
|-------|-------|
| **Rotate** | ![Rotate](assets/screenshots/rotate.png) |
| **Slider** | ![Slider](assets/screenshots/slider.png) |
| **Pair** | ![Pair](assets/screenshots/pair.png) |

## Architecture

anCaptcha is structured as a workspace with the following core crates:

- **`crates/ancaptcha`**: Core engine handling challenge generation, authenticated encryption, and verification logic.
- **`crates/ancaptcha-ffi`**: C-ABI bridge for multi-language consumption.

## Configuration

The engine is configured through a central `Config` struct (Rust) or via the FFI initialization calls (Wrappers).

Generate a 32-byte hex key for authenticated encryption:
```bash
openssl rand -hex 32
```

### Global Configuration

| Property | Type | Default | Description |
|-----------|------|---------|-------------|
| `secret` | 32-byte | (Required) | Key for authenticated encryption. must be identical across nodes. |
| `difficulty` | Enum | `Medium` | Challenge complexity: `Easy` (1 step), `Medium` (2 steps), `Hard` (3 steps). |
| `noise_intensity` | Enum | `Medium` | Distortion level (`0: Low`, `1: Medium`, `2: High`). |


### Captcha Styles
| Style | Index | Description |
|-------|-------|-------------|
| `Rotate` | `0` | Rotate image to upright position. |
| `Slider` | `1` | Slide puzzle piece into place. |
| `Pair` | `2` | Find the matching image pair. |

### Visual Customization (Theme)
Default values for the `Theme` struct and `anCaptcha_set_theme`:

| Property | Default | Description |
|----------|---------|-------------|
| `background_color` | `#f9f9f9` | Main container background. |
| `border_color` | `#d3d3d3` | Outer border color. |
| `text_color` | `#333333` | Primary text color. |
| `accent_color` | `#14B8A6` | Primary button/checkbox color. |
| `error_color` | `#fb7185` | Error message and invalid state color. |
| `font_family` | (System) | Sans-serif font stack. |

### Structural Customization (Layout)
Default values for the `Layout` struct and `anCaptcha_set_layout`:

| Property | Default | Description |
|----------|---------|-------------|
| `width` | `100%` | Container width. |
| `max_width` | `25em` | Maximum container width. |
| `margin` | `1.25em auto` | Container margin. |
| `min_height` | `3.5em` | Initial trigger height. |
| `padding` | `0.5em 0.9em` | Container padding. |
| `checkbox_size` | `1.8em` | Custom checkbox dimensions. |

### Component Size Profile
| Profile | Base Font Size | Description |
|---------|----------------|-------------|
| `Small` | `12px` | Compact layout. |
| `Medium` | `14px` | Standard layout. |
| `Large` | `16px` | Large layout (Default). |

## Installation (Rust)

*If you are not using Rust, skip directly to the **[Pre-built Library](#pre-built-library-go-python-php)** section below.*

### From Crates.io
```bash
cargo add ancaptcha
```

### From My Registry
Add the registry to your local `.cargo/config.toml`:

```toml
[registries.maverick]
index = "sparse+https://git.mrmave.work/api/packages/maverick/cargo/"

[net]
git-fetch-with-cli = true
```

Then install:
```bash
cargo add ancaptcha --registry maverick
```

## Quick Start (Build from Source)

Requires Linux and Rust.

```bash
# 1. Clone
git clone https://git.mrmave.work/maverick/ancaptcha.git

# Tor
git -c http.proxy=socks5h://127.0.0.1:9050 clone http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha

# 2. Build
cd ancaptcha
make build
```

## Custom Assets

You can add your own images by placing them in `crates/ancaptcha/assets/original_images/`. The pipeline converts `.jpg`, `.jpeg`, and `.png` files into optimized 200x200 WebP artifacts (<3.5KB).

```bash
make assets
make build
```

## Pre-built Library (Go, Python, PHP)

Pre-built binaries, headers, and signatures are available in the `dist/` directory or via [Releases](https://git.mrmave.work/maverick/ancaptcha/releases).

### 1. TL;DR Quick Setup (Wrappers)

Extract the FFI library and header, then download the wrapper for your language. Place all three files together in your project.

**Go**
```bash
wget -qO- https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && wget -q https://git.mrmave.work/maverick/ancaptcha/raw/branch/main/examples/go/ancaptcha/ancaptcha.go
```
**Go (Tor)**
```bash
torsocks wget -qO- http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/dist/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | torsocks tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && torsocks wget -q http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/examples/go/ancaptcha/ancaptcha.go
```

**Python**
```bash
wget -qO- https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && wget -q https://git.mrmave.work/maverick/ancaptcha/raw/branch/main/examples/python/ancaptcha.py
```
**Python (Tor)**
```bash
torsocks wget -qO- http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/dist/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | torsocks tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && torsocks wget -q http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/examples/python/ancaptcha.py
```

**PHP**
```bash
wget -qO- https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && wget -q https://git.mrmave.work/maverick/ancaptcha/raw/branch/main/examples/php/AnCaptcha.php
```
**PHP (Tor)**
```bash
torsocks wget -qO- http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/dist/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz | torsocks tar -xz --strip-components=1 ancaptcha-ffi-v0.4.1-linux-x86_64/libancaptcha_ffi.so ancaptcha-ffi-v0.4.1-linux-x86_64/ancaptcha-ffi.h && torsocks wget -q http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/examples/php/AnCaptcha.php
```

### 2. Manual Verification (Recommended)

Verify the release signatures before extraction to ensure cryptographic integrity.

```bash
# 1. Import Key
# Tor
torsocks wget http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/certs/maverick.asc
gpg --import maverick.asc

# WKD
gpg --locate-keys mail@mrmave.work

# 2. Download Artifacts and Signatures
wget https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz
wget https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz.sha256
wget https://git.mrmave.work/maverick/ancaptcha/releases/download/v0.4.1/ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz.asc

# 3. Verify
sha256sum -c ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz.sha256
gpg --verify ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz.asc ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz

# 4. Extract
tar -xzf ancaptcha-ffi-v0.4.1-linux-x86_64.tar.gz
```

*(Note: If accessing via Tor, use `torsocks` and replace the base URL with `http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha/plain/dist/` for all artifacts and signatures).*

## Security and Compliance

Continuous fuzzing and dependency auditing are integrated into the development process. Testing covers edge-case discovery in the verification engine and memory safety verification for the FFI bridge. The dependency manifest is also audited for security vulnerabilities and compliance. All security documentation, including fuzzing statistics, memory safety reports, and dependency audit logs, is available in [docs/SECURITY.md](docs/SECURITY.md).

## Repositories

- **Main**: [git.mrmave.work/maverick/ancaptcha](https://git.mrmave.work/maverick/ancaptcha)
- **Mirror (Tor)**: [mavegit...onion/ancaptcha](http://mavegitwskioz7tpppmjtj7fn24pwezciii3nvc7kdyltn5iu5uakfqd.onion/ancaptcha)
- **Mirror (Codeberg)**: [codeberg.org/mrmave/ancaptcha](https://codeberg.org/mrmave/ancaptcha)

## License

(c) 2026 Maverick. Licensed under the Apache-2.0 License.

## Donation

**Monero (XMR)**: `86FSeePspHNgbS29usjrtudPE1PTP2UjJLhB9vdXp3WjD9EYAibdS171SdT2dmcC7ZC6t9iPYd6StEeiXFNj6YNhRRcQyJi`
